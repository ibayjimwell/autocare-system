// @/app-utils/services/helpers.ts

export const formatPrice = (price: any): string => {
  const num = parseFloat(price);
  return isNaN(num) ? "0.00" : num.toLocaleString("en-PH", { minimumFractionDigits: 2 });
};

export const typeBadgeConfig: Record<string, string> = {
  PMS: "bg-emerald-100 text-emerald-800",
  REPAIR: "bg-primary/10 text-primary",
  CHECKUP: "bg-blue-100 text-blue-800",
  MODIFICATION: "bg-purple-100 text-purple-800",
};

export const SERVICE_TYPES = [
  "PMS",
  "REPAIR",
  "CHECKUP",
  "MODIFICATION",
] as const;

export const SERVICE_TYPE_LABELS: Record<string, string> = {
  PMS: "Preventive Maintenance Service (PMS)",
  REPAIR: "Repair",
  CHECKUP: "Checkup / Inspection",
  MODIFICATION: "Modification",
};