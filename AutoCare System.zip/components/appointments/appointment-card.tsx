'use client';

import React, {
  useState,
} from 'react';

import StatusBadge from '@/components/shared/status-badge';

import {
  Calendar,
  Clock,
  AlertCircle,
  ChevronDown,
  User,
  Car,
  Eye,
  CalendarClock,
} from 'lucide-react';

import {
  cn,
} from '@/lib/utils';

import StatusAccentBar from './status-accent-bar';

import AppointmentNotesCard from './appointment-notes-card';

import {
  canReschedule,
} from '@/app-utils/appointments/helpers';

import {
  Button,
} from '@/components/ui/button';

import AppointmentDetailModal from './AppointmentDetailModal';

import {
  useAppointmentDetailModal,
} from '@/hooks/appointments/useAppointmentDetailModal';

/* ================================================================
   TYPES
================================================================ */

interface AppointmentData {
  id: string;

  customerId: string;

  vehicleId: string;

  services:
    | any[]
    | null;

  trackingNumber: string;

  appointmentDate: string;

  appointmentTime: string;

  status: string;

  notes:
    | string
    | null;

  createdAt: string;

  updatedAt: string;

  customer?: {
    id?: string;

    fullname: string;
  };

  vehicle?: {
    id?: string;

    plateNumber: string;

    model: string;

    make?: string;

    year?: number;
  };
}

interface AppointmentCardProps {
  appointment: AppointmentData;

  children?: React.ReactNode;

  className?: string;

  pendingRescheduleCount?: number;

  onReschedule?: (
    appointment: AppointmentData,
  ) => void;
}

/* ================================================================
   COMPONENT
================================================================ */

export default function AppointmentCard({
  appointment,
  children,
  className,
  pendingRescheduleCount = 0,
  onReschedule,
}: AppointmentCardProps) {
  const [
    expanded,
    setExpanded,
  ] = useState(false);

  /* ==============================================================
     DETAIL MODAL HOOK
  ============================================================== */

  const {
    open,
    openModal,
    closeModal,

    loading:
      detailLoading,

    refreshing,

    appointment:
      detailAppointment,

    customer:
      detailCustomer,

    vehicle:
      detailVehicle,

    services:
      detailServices,

    history:
      detailHistory,

    inspectionTasks,

    workTasks,

    findings,

    estimate,

    finalBill,

    queue,

    enabledSections,

    confirmationLog,

    inspectionLog,

    waitingApprovalLog,

    inProgressLog,

    completedLog,

    estimateSentAt,

    estimateSentBy,

    estimateApprovedAt,

    estimateApprovedBy,

    refresh,
  } =
    useAppointmentDetailModal(
      appointment?.id,
    );

  /* ==============================================================
     INVALID DATA
  ============================================================== */

  if (!appointment) {
    return (
      <div
        className={cn(
          `
            flex
            w-full
            items-center
            gap-2
            rounded-lg
            border
            border-destructive/25
            bg-destructive/10
            p-3
            text-destructive

            md:p-4
          `,
          className,
        )}
      >
        <AlertCircle
          className="
            h-4
            w-4
            shrink-0
          "
        />

        <span
          className="
            text-xs
            font-medium
          "
        >
          Invalid appointment
          data.
        </span>
      </div>
    );
  }

  /* ==============================================================
     STATUS
  ============================================================== */

  const hasPendingReschedule =
    pendingRescheduleCount >
    0;

  const isReschedulable =
    canReschedule(
      appointment.status,
    );

  /*
   * Details are expandable when:
   *
   * - appointment has children
   * - appointment can be rescheduled
   */
  const hasDetails =
    !!children ||
    (isReschedulable &&
      !!onReschedule) ||
    !!appointment.notes;

  /* ==============================================================
     RENDER
  ============================================================== */

  return (
    <>
      {/* ==========================================================
          APPOINTMENT CARD
      =========================================================== */}

      <div
        className={cn(
          `
            group
            relative
            w-full
            overflow-hidden
            rounded-lg
            border
            border-border
            bg-card
            text-card-foreground
            shadow-sm
            transition-shadow
            hover:shadow-md
          `,
          hasPendingReschedule &&
            `
              border-blue-500/30
              ring-1
              ring-blue-500/10
            `,
          className,
        )}
      >
        {/* ========================================================
            STATUS ACCENT
        ========================================================= */}

        <StatusAccentBar
          status={
            appointment.status
          }
        />

        <div
          className="
            p-3
            md:p-3.5
          "
        >
          {/* ======================================================
              SUMMARY
          ======================================================= */}

          <div
            className="
              flex
              items-start
              justify-between
              gap-3
            "
          >
            {/* ====================================================
                LEFT
            ===================================================== */}

            <div
              className="
                min-w-0
                flex-1
              "
            >
              <div
                className="
                  flex
                  flex-wrap
                  items-center
                  gap-2
                "
              >
                <span
                  className="
                    truncate
                    text-sm
                    font-bold
                    uppercase
                    tracking-wide
                    text-foreground
                  "
                >
                  #
                  {
                    appointment.trackingNumber
                  }
                </span>

                {/* ===============================================
                    RESCHEDULE INDICATOR
                ================================================= */}

                {hasPendingReschedule && (
                  <span
                    className="
                      inline-flex
                      items-center
                      gap-1.5
                      rounded-full
                      border
                      border-blue-500/25
                      bg-blue-500/10
                      px-2
                      py-0.5
                      text-[9px]
                      font-bold
                      uppercase
                      tracking-wider
                      text-blue-600
                      dark:text-blue-400
                    "
                  >
                    <span
                      className="
                        relative
                        flex
                        h-2
                        w-2
                      "
                    >
                      <span
                        className="
                          absolute
                          inline-flex
                          h-2
                          w-2
                          animate-ping
                          rounded-full
                          bg-blue-500/70
                        "
                      />

                      <span
                        className="
                          relative
                          inline-flex
                          h-2
                          w-2
                          rounded-full
                          bg-blue-500
                        "
                      />
                    </span>

                    <CalendarClock
                      className="
                        h-3
                        w-3
                      "
                    />

                    Reschedule
                  </span>
                )}
              </div>

              {/* =================================================
                  CUSTOMER / VEHICLE
              ================================================== */}

              <div
                className="
                  mt-1
                  flex
                  flex-wrap
                  items-center
                  gap-x-3
                  gap-y-1
                "
              >
                {appointment.customer
                  ?.fullname && (
                  <span
                    className="
                      flex
                      min-w-0
                      items-center
                      gap-1.5
                      text-xs
                      font-medium
                      text-foreground
                    "
                  >
                    <User
                      className="
                        h-3.5
                        w-3.5
                        shrink-0
                        text-primary
                      "
                    />

                    <span className="truncate">
                      {
                        appointment
                          .customer
                          .fullname
                      }
                    </span>
                  </span>
                )}

                {appointment.vehicle
                  ?.plateNumber && (
                  <span
                    className="
                      flex
                      shrink-0
                      items-center
                      gap-1
                      text-[10px]
                      font-semibold
                      uppercase
                      tracking-wide
                      text-muted-foreground
                    "
                  >
                    <Car
                      className="
                        h-3
                        w-3
                      "
                    />

                    {
                      appointment
                        .vehicle
                        .plateNumber
                    }
                  </span>
                )}
              </div>
            </div>

            {/* ===================================================
                ACTIONS
            ==================================================== */}

            <div
              className="
                flex
                shrink-0
                items-center
                gap-1
              "
            >
              <StatusBadge
                status={
                  appointment.status
                }
                className="
                  shrink-0
                  scale-90
                "
              />

              {/* =================================================
                  VIEW
              ================================================== */}

              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={() =>
                  void openModal()
                }
                aria-label="View appointment details"
                className="
                  h-9
                  w-9
                  rounded-md
                  text-muted-foreground
                  hover:bg-primary/5
                  hover:text-primary

                  focus-visible:outline-none
                  focus-visible:ring-2
                  focus-visible:ring-ring
                  focus-visible:ring-offset-2

                  md:h-8
                  md:w-8
                "
              >
                <Eye className="h-4 w-4" />
              </Button>

              {/* =================================================
                  EXPAND
              ================================================== */}

              {hasDetails && (
                <button
                  type="button"
                  onClick={() =>
                    setExpanded(
                      (
                        previous,
                      ) =>
                        !previous,
                    )
                  }
                  aria-expanded={
                    expanded
                  }
                  aria-label={
                    expanded
                      ? 'Collapse appointment details'
                      : 'Expand appointment details'
                  }
                  className="
                    flex
                    h-9
                    w-9
                    items-center
                    justify-center
                    rounded-md
                    text-muted-foreground
                    transition-colors
                    hover:bg-accent
                    hover:text-foreground

                    focus-visible:outline-none
                    focus-visible:ring-2
                    focus-visible:ring-ring
                    focus-visible:ring-offset-2

                    md:h-8
                    md:w-8
                  "
                >
                  <ChevronDown
                    className={cn(
                      `
                        h-4
                        w-4
                        transition-transform
                        duration-200
                      `,
                      expanded &&
                        'rotate-180',
                    )}
                  />
                </button>
              )}
            </div>
          </div>

          {/* ======================================================
              DATE + TIME
          ======================================================= */}

          <div
            className="
              mt-2
              flex
              flex-wrap
              items-center
              gap-x-4
              gap-y-1
            "
          >
            <span
              className="
                flex
                items-center
                gap-1.5
                text-[11px]
                font-medium
                text-muted-foreground
              "
            >
              <Calendar
                className="
                  h-3.5
                  w-3.5
                  text-primary
                "
              />

              {appointment.appointmentDate
                ? new Date(
                    `${appointment.appointmentDate}T00:00:00`,
                  ).toLocaleDateString(
                    'en-US',
                    {
                      month:
                        'short',
                      day:
                        'numeric',
                    },
                  )
                : 'N/A'}
            </span>

            <span
              className="
                flex
                items-center
                gap-1.5
                text-[11px]
                font-medium
                tabular-nums
                text-muted-foreground
              "
            >
              <Clock
                className="
                  h-3.5
                  w-3.5
                "
              />

              {appointment.appointmentTime
                ? appointment.appointmentTime.slice(
                    0,
                    5,
                  )
                : 'N/A'}
            </span>
          </div>

          {/* ======================================================
              EXPANDABLE CONTENT
          ======================================================= */}

          {hasDetails && (
            <div
              className={cn(
                'flex-col gap-2',
                expanded
                  ? `
                    mt-3
                    flex
                    border-t
                    border-border
                    pt-3
                  `
                  : 'hidden',
              )}
            >
              {/* ==================================================
                  NOTES CARD
              =================================================== */}

              <AppointmentNotesCard
                notes={
                  appointment.notes
                }
              />

              {/* ==================================================
                  EXISTING CHILDREN
              =================================================== */}

              {children}

              {/* ==================================================
                  RESCHEDULE
              =================================================== */}

              {isReschedulable &&
                onReschedule && (
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    onClick={() =>
                      onReschedule(
                        appointment,
                      )
                    }
                    className="
                      relative
                      mt-1
                      h-10
                      w-full
                      rounded-md
                      px-3
                      text-xs
                      font-medium

                      focus-visible:outline-none
                      focus-visible:ring-2
                      focus-visible:ring-ring
                      focus-visible:ring-offset-2

                      sm:w-auto
                      md:h-9
                    "
                  >
                    <Calendar
                      className="
                        h-3.5
                        w-3.5
                      "
                    />

                    Reschedule

                    {hasPendingReschedule && (
                      <span
                        className="
                          absolute
                          -right-1
                          -top-1
                          flex
                          h-3
                          w-3
                        "
                      >
                        <span
                          className="
                            absolute
                            h-3
                            w-3
                            animate-ping
                            rounded-full
                            bg-blue-500/60
                          "
                        />

                        <span
                          className="
                            relative
                            h-3
                            w-3
                            rounded-full
                            bg-blue-500
                          "
                        />
                      </span>
                    )}
                  </Button>
                )}
            </div>
          )}
        </div>
      </div>

      {/* ===========================================================
          DETAIL MODAL
      ============================================================ */}

      <AppointmentDetailModal
        open={
          open
        }
        onOpenChange={(
          nextOpen,
        ) => {
          if (
            nextOpen
          ) {
            return;
          }

          closeModal();
        }}
        loading={
          detailLoading
        }
        refreshing={
          refreshing
        }
        appointment={
          detailAppointment ||
          appointment
        }
        customer={
          detailCustomer ||
          appointment.customer
        }
        vehicle={
          detailVehicle ||
          appointment.vehicle
        }
        services={
          detailServices
        }
        history={
          detailHistory
        }
        inspectionTasks={
          inspectionTasks
        }
        workTasks={
          workTasks
        }
        findings={
          findings
        }
        estimate={
          estimate
        }
        finalBill={
          finalBill
        }
        queue={
          queue
        }
        enabledSections={
          enabledSections
        }
        confirmationLog={
          confirmationLog
        }
        inspectionLog={
          inspectionLog
        }
        waitingApprovalLog={
          waitingApprovalLog
        }
        inProgressLog={
          inProgressLog
        }
        completedLog={
          completedLog
        }
        estimateSentAt={
          estimateSentAt
        }
        estimateSentBy={
          estimateSentBy
        }
        estimateApprovedAt={
          estimateApprovedAt
        }
        estimateApprovedBy={
          estimateApprovedBy
        }
        onRefresh={
          refresh
        }
      />
    </>
  );
}