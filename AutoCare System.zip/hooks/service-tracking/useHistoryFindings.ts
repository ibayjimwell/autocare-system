'use client';

import {
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react';

import { historyFindingsApi } from '@/lib/service-tracking/history-findings';
import { toast } from 'sonner';

/* ================================================================
   TYPES
================================================================ */

type HistoryFindingPhase =
  | 'INSPECTION'
  | undefined;

/* ================================================================
   HISTORY FINDINGS HOOK
================================================================ */

export function useHistoryFindings(
  search?: string,
  phase?: HistoryFindingPhase,
  options?: {
    enabled?: boolean;
    appointmentId?: string;
    excludeAppointmentId?: string;
    debounceMs?: number;
  },
) {
  const [findings, setFindings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const requestIdRef = useRef(0);

  const enabled = options?.enabled ?? true;
  const debounceMs = options?.debounceMs ?? 250;

  /* ==============================================================
     LOAD
  ============================================================== */

  const loadFindings = useCallback(
    async (loadOptions?: { silent?: boolean }) => {
      if (!enabled) {
        return [];
      }

      const requestId =
        requestIdRef.current + 1;
      requestIdRef.current = requestId;

      const silent = loadOptions?.silent ?? false;

      if (silent) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      try {
        const res = await historyFindingsApi.list({
          appointmentId:
            options?.appointmentId,
          excludeAppointmentId:
            options?.excludeAppointmentId,
          search:
            search?.trim() || undefined,
          phase:
            phase || undefined,
          all: true,
        });

        if (requestId !== requestIdRef.current) {
          return [];
        }

        if (res?.error) {
          toast.error(
            res.errorMessage ||
              'Failed to load history findings.',
          );
          setFindings([]);
          return [];
        }

        const nextFindings = Array.isArray(res?.data)
          ? res.data
          : [];

        setFindings(nextFindings);
        return nextFindings;
      } catch (err: any) {
        if (requestId !== requestIdRef.current) {
          return [];
        }

        console.error(
          '[useHistoryFindings] Failed to load history findings:',
          err,
        );

        toast.error(
          err?.message ||
            'Error loading history findings.',
        );

        setFindings([]);
        return [];
      } finally {
        if (requestId === requestIdRef.current) {
          if (silent) {
            setRefreshing(false);
          } else {
            setLoading(false);
          }
        }
      }
    },
    [
      enabled,
      options?.appointmentId,
      options?.excludeAppointmentId,
      phase,
      search,
    ],
  );

  /* ==============================================================
     SEARCH / FILTER LOAD
  ============================================================== */

  useEffect(() => {
    if (!enabled) {
      setLoading(false);
      return;
    }

    const timer = setTimeout(() => {
      void loadFindings();
    }, debounceMs);

    return () => {
      clearTimeout(timer);
      requestIdRef.current += 1;
    };
  }, [
    enabled,
    debounceMs,
    loadFindings,
  ]);

  return {
    findings,
    loading,
    refreshing,
    loadFindings,
  };
}
