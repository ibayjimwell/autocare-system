// Models

// Staffs
export * from "./staffs/staffs.model";
export * from "./staffs/staff-access.model";

// Customers
export * from "./customers/customers.model";
export * from "./customers/vehicles.model";
export * from "./customers/password-reset-otps.model"
export * from "./customers/phone-verification-otps.model"

// Services
export * from "./services/services.model";

// Appointments
export * from "./appointments/appointments.model";
export * from "./appointments/appointments-status-history.model";
export * from "./appointments/enum/appointments-status.enum";
export * from "./appointments/appointment-reschedule-requests.model";

// Service Tracking
export * from "./service-tracking/inspection-tasks.model";
export * from "./service-tracking/inspection-findings.model";
export * from "./service-tracking/inspection-finding-parts.model";
export * from "./service-tracking/work-tasks.model";
export * from "./service-tracking/default-task-groups.model";
export * from "./service-tracking/default-tasks.model";
export * from "./service-tracking/task-history.model"
export * from "./service-tracking/default-findings.model"
export * from "./service-tracking/default-finding-parts.model"
export * from "./service-tracking/history-findings.model"
export * from "./service-tracking/history-finding-parts.model"

// Billing
export * from "./payments/estimated-costs.model";
export * from "./payments/estimate-findings.model";
export * from "./payments/estimate-finding-parts.model";
export * from "./payments/estimate-tasks.model";
export * from "./payments/estimate-fees.model";
export * from "./payments/estimate-discounts.model";

export * from "./payments/final-bill.model";
export * from "./payments/final-bill-findings.model";
export * from "./payments/final-bill-finding-parts.model";
export * from "./payments/final-bill-fees.model";
export * from "./payments/final-bill-discounts.model";
export * from "./payments/final-bill-work-tasks.model";

export * from "./payments/receipts.model";

// Inventory
export * from "./inventory/inventory.model";
export * from "./inventory/pos-transaction.model";
export * from "./inventory/inventory-allocation.model";
export * from "./inventory/enum/inventory-allocation-status.enum";

// Notifications
export * from "./notifications/push-subscription.model";
export * from "./notifications/customer-push-subscription.model";

// Queue
export * from "./queue/service-queue.model";

// Configurations
export * from "./configurations/configurations.model";
export * from "./configurations/configurations-logs.model";


// Dashboard Analytics (derived read-model types)
export * from './dashboard/dashboard.model';
